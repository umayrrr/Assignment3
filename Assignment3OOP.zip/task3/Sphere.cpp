#include "Sphere.h"

Sphere ::Sphere(double side) : ThreeDimensionalShape(side, 0, 0) {}

Sphere ::Sphere(const Sphere &obj) : ThreeDimensionalShape(obj) {}

Sphere &Sphere ::operator=(const Sphere &obj)
{
    this->length = obj.length;
    this->width = obj.width;
    this->height = obj.height;
    return *this;
}

double Sphere::volume(void) const
{
    return 1.333 * 3.14 * this->length * this->length * this->length;
}

void Sphere ::display(void)
{
    std::cout << "radious: " << this->length << std ::endl;
    std::cout << "volume: " << this->volume() << std::endl;
}

Sphere ::~Sphere() {}

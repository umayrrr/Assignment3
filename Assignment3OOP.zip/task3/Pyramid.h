#pragma once
#include "ThreeDimensionalShape.h"
class Pyramid : public ThreeDimensionalShape
{
public:
    Pyramid(double=0, double=0, double=0);
    Pyramid(const Pyramid &);
    Pyramid &operator=(const Pyramid &);
    double volume(void) const;
    void display(void);
    ~Pyramid();
};

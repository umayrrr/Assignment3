#pragma once
#include "TwoDimensionalShape.h"
class Triangle : public TwoDimensionalShape
{
public:
	Triangle(double base = 0, double height = 0);
	Triangle(const Triangle &);
	double area(void);
	void display(void);
	~Triangle();
};

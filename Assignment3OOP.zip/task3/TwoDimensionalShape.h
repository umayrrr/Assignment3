#pragma once
#include "Shape.h"
class TwoDimensionalShape : public Shape
{
protected:
public:
    TwoDimensionalShape(double width = 0, double length_height = 0);
    TwoDimensionalShape(const TwoDimensionalShape &);
    TwoDimensionalShape &operator=(const TwoDimensionalShape &);
    ~TwoDimensionalShape();
};
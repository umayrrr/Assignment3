#include "TwoDimensionalShape.h"

TwoDimensionalShape::TwoDimensionalShape(double length, double width) : Shape(length, width, 0) {}

TwoDimensionalShape::TwoDimensionalShape(const TwoDimensionalShape &obj) : Shape(obj) {}

TwoDimensionalShape &TwoDimensionalShape::operator=(const TwoDimensionalShape &obj)
{
    this->length = obj.length;
    this->width = obj.width;
    this->height = obj.height;
    return *this;
}

TwoDimensionalShape::~TwoDimensionalShape() {}
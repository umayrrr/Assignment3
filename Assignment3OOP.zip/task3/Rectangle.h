#pragma once
#include "TwoDimensionalShape.h"
class Rectangle : public TwoDimensionalShape
{
public:
	Rectangle(double = 0, double = 0);
	Rectangle(const Rectangle &);
	Rectangle& operator=(const Rectangle &);
	void display(void);
	~Rectangle();
};

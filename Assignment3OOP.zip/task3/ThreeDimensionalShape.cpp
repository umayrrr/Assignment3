#include "ThreeDimensionalShape.h"

ThreeDimensionalShape::ThreeDimensionalShape(double length, double width, double height) : Shape(length, width, height) {}

ThreeDimensionalShape::ThreeDimensionalShape(const ThreeDimensionalShape &obj) : Shape(obj) {}

ThreeDimensionalShape &ThreeDimensionalShape::operator=(const ThreeDimensionalShape &obj)
{
    this->length = obj.length;
    this->width = obj.width;
    this->height = obj.height;
    return *this;
}

ThreeDimensionalShape::~ThreeDimensionalShape() {}

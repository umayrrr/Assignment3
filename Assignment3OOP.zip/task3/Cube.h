#pragma once
#include "ThreeDimensionalShape.h"
class Cube : public ThreeDimensionalShape
{
public:
    Cube(double = 0);
    Cube(const Cube &);
    Cube &operator=(const Cube &);
    void display(void);
    ~Cube();
};

#include "Torus.h"

Torus::Torus(double radious) : ThreeDimensionalShape(radious, 0, 0) {}

Torus::Torus(const Torus &obj) : ThreeDimensionalShape(obj) {}
Torus &Torus::operator=(const Torus &obj)
{
    this->length = obj.length;
    this->width = obj.width;
    this->height = obj.height;
    return *this;
}

double Torus::volume(void) const
{
    return 3.14 * this->length * this->length * 2.0 * 3.14 * this->length;
}

void Torus::display(void)
{
    std::cout << "Radius: " << this->length << std::endl;
    std::cout << "volume: " << this->volume() << std::endl;
}

Torus::~Torus() {}

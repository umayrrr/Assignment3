#pragma once
#include "ThreeDimensionalShape.h"
class Sphere : public ThreeDimensionalShape
{
public:
    Sphere(double = 0);
    Sphere(const Sphere &);
    Sphere &operator=(const Sphere &);
    double volume(void) const;
    void display(void);
    ~Sphere();
};

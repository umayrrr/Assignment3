#pragma once
#include "ThreeDimensionalShape.h"
class Cylender : public ThreeDimensionalShape
{
public:
    Cylender(double = 0, double = 0);
    Cylender(const Cylender &);
    Cylender &operator=(const Cylender &);
    double volume(void) const;
    void display(void);
    ~Cylender();
};
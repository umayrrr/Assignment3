#include "Circle.h"

Circle::Circle(double radious) : TwoDimensionalShape(radious, 0.0) {}

Circle::Circle(const Circle &obj) : TwoDimensionalShape(obj) {}

Circle &Circle::operator=(const Circle &obj)
{
	this->length = obj.length;
	this->width = obj.width;
	this->height = obj.height;
	return *this;
}

double Circle::area(void) const
{
	return 3.14 * length * length;
}

void Circle::display(void)
{
	std::cout << "Radius: " << this->length << std::endl;
	std::cout << "area: " << this->area() << std::endl;
}

Circle::~Circle() {}

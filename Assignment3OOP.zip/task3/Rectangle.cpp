#include "Rectangle.h"

Rectangle::Rectangle(double length, double width) : TwoDimensionalShape(length, width) {}

Rectangle::Rectangle(const Rectangle &obj) : TwoDimensionalShape(obj) {}

Rectangle &Rectangle::operator=(const Rectangle &obj)
{
    this->length = obj.length;
    this->width = obj.width;
    this->height = obj.height;
    return *this;
}

void Rectangle::display(void)
{
    std::cout << "length: " << this->height << std ::endl;
    std::cout << "width: " << this->width << std ::endl;
    std::cout << "area: " << this->area() << std::endl;
}

Rectangle::~Rectangle() {}

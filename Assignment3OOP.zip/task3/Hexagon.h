#pragma once
#include "TwoDimensionalShape.h"
class Hexagon : public TwoDimensionalShape
{
public:
    Hexagon(double=0);
    Hexagon(const Hexagon &);
    Hexagon &operator=(const Hexagon &);
    double area(void);
    void display(void);
    ~Hexagon();
};

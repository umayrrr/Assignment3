#include "Triangle.h"
#include "Circle.h"
#include "Square.h"
#include "Rectangle.h"
#include "Hexagon.h"
#include "Pentagon.h"
#include "Cube.h"
#include "Sphere.h"
#include "Cylender.h"
#include "Pyramid.h"
#include "Cone.h"
#include "Torus.h"
int main()
{
	std::cout << "TwoDimensionalShape: " << std::endl;
	std::cout << "^^^^^^^^^^^^^^^^^^^^ " << std::endl;
	std::cout << "Triangle: " << std::endl;
	Triangle triangle(2.1, 3.1);
	triangle.display();
	std::cout << "Rectangle: " << std::endl;
	Rectangle rectangle(2.1, 3.1);
	rectangle.display();
	std::cout << "Square: " << std::endl;
	Square square(2.1);
	square.display();
	std::cout << "Circle: " << std::endl;
	Circle circle(2.1);
	circle.display();
	std::cout << "Hexagon: " << std::endl;
	Hexagon hexagon(2.1);
	hexagon.display();
	std::cout << "Pentagon: " << std::endl;
	Pentagon pentagon(2.1);
	pentagon.display();
	std::cout << "ThreeDimensionalShape: " << std::endl;
	std::cout << "^^^^^^^^^^^^^^^^^^^^ " << std::endl;
	std::cout << "Cube: " << std::endl;
	Cube cube(2.1);
	cube.display();
	std::cout << "Sphere: " << std::endl;
	Sphere sphere(2.1);
	sphere.display();
	std::cout << "cylender: " << std::endl;
	Cylender cylender(2.1, 3.1);
	cylender.display();
	std::cout << "pyramid: " << std::endl;
	Pyramid pyramid(2.1, 3.1, 4.1);
	pyramid.display();
	std::cout << "cone: " << std::endl;
	Cone cone(2.1, 3.1);
	cone.display();
	std::cout << "torus: " << std::endl;
	Torus torus(2.1);
	torus.display();
	/*
Torus: The volume of a torus is calculated by multiplying the area of the cross section (a circle) by the circumference of the torus. The formula is: V = 2π^2 * R * r^2, where V is the volume, R is the major radius and r is the minor radius of the torus.
	*/

	return 0;
}
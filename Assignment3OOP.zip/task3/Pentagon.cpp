#include "Pentagon.h"

#include "Pentagon.h"

Pentagon::Pentagon(double side) : TwoDimensionalShape(side, 0) {}

Pentagon::Pentagon(const Pentagon &obj) : TwoDimensionalShape(obj) {}

Pentagon &Pentagon::operator=(const Pentagon &obj)
{
    this->length = obj.length;
    this->width = obj.width;
    this->height = obj.height;
    return *this;
}

double Pentagon::area(void)
{
    return (6.881909602 / 4) * this->length * this->length;
}

void Pentagon::display(void)
{
    std::cout << "Side: " << this->length << std::endl;
    std::cout << "Area: " << this->area() << std::endl;
}

Pentagon::~Pentagon() {}

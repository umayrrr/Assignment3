#pragma once
#include "Shape.h"
class ThreeDimensionalShape : public Shape
{
protected:
public:
    ThreeDimensionalShape(double = 0, double = 0, double = 0);
    ThreeDimensionalShape(const ThreeDimensionalShape &);
    ThreeDimensionalShape &operator=(const ThreeDimensionalShape &);
    ~ThreeDimensionalShape();
};

#include "Cone.h"

Cone::Cone(double radious, double height) : ThreeDimensionalShape(radious, 0, height) {}

Cone::Cone(const Cone &obj) : ThreeDimensionalShape(obj) {}

Cone &Cone::operator=(const Cone &obj)
{
    this->length = obj.length;
    this->width = obj.width;
    this->height = obj.height;
    return *this;
}

double Cone::volume(void) const
{
    return (3.14 * this->length * this->length * this->height) / 3.0;
}

void Cone::display(void)
{

    std::cout << "radious: " << this->length << std ::endl;
    std::cout << "height: " << this->height << std ::endl;
    std::cout << "volume: " << this->volume() << std::endl;
}

Cone::~Cone() {}

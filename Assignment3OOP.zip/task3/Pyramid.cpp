#include "Pyramid.h"

Pyramid::Pyramid(double lengthOfBase, double widthOfBase, double height) : ThreeDimensionalShape(lengthOfBase, widthOfBase, height) {}

Pyramid::Pyramid(const Pyramid &obj) : ThreeDimensionalShape(obj) {}

Pyramid &Pyramid::operator=(const Pyramid &obj)
{
    this->length = obj.length;
    this->width = obj.width;
    this->height = obj.height;
    return *this;
}

double Pyramid::volume(void) const
{
    return (this->length * this->width * this->height) / 3.0;
}

void Pyramid::display(void)
{
    std::cout << "length of base: " << this->length << std ::endl;
    std::cout << "width of base: " << this->width << std ::endl;
    std::cout << "height: " << this->height << std ::endl;
    std::cout << "volume: " << this->volume() << std::endl;
}

Pyramid::~Pyramid() {}

#pragma once
#include "TwoDimensionalShape.h"
class Pentagon : public TwoDimensionalShape
{
public:
    Pentagon(double=0);
    Pentagon(const Pentagon &);
    Pentagon &operator=(const Pentagon &);
    double area(void);
    void display(void);
    ~Pentagon();
};

#pragma once
#include <iostream>
class Shape
{
protected:
	double length;
	double width;
	double height;

public:
	Shape(double = 0, double = 0, double = 0);
	Shape(const Shape &);
	Shape &operator=(const Shape &);
	double area(void) const;
	double volume(void) const;
	~Shape(void);
};

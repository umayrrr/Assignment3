#pragma once
#include "TwoDimensionalShape.h"
class Square : public TwoDimensionalShape
{
public:
	Square(double = 0);
	Square(const Square &);
	Square &operator=(const Square &);
	void display(void);
	~Square();
};

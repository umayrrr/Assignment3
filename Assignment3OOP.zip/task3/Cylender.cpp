#include "Cylender.h"

Cylender::Cylender(double radious, double height) : ThreeDimensionalShape(0, radious, height) {}

Cylender::Cylender(const Cylender &obj) : ThreeDimensionalShape(obj) {}

Cylender &Cylender::operator=(const Cylender &obj)
{
    this->length = obj.length;
    this->width = obj.width;
    this->height = obj.height;
    return *this;
}

double Cylender::volume(void) const
{
    return 3.14 * this->width * this->width * this->height;
}

void Cylender::display(void)
{
    std::cout << "radious: " << this->width << std::endl;
    std::cout << "height: " << this->height << std::endl;
    std::cout << "volume: " << this->volume() << std::endl;
}

Cylender::~Cylender() {}

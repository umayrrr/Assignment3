#include "Square.h"

Square::Square(double side) : TwoDimensionalShape(side, side) {}

Square::Square(const Square &obj) : TwoDimensionalShape(obj) {}

Square &Square::operator=(const Square &obj)
{
    this->length = obj.length;
    this->width = obj.width;
    this->height = obj.height;
    return *this;
}

void Square::display(void)
{
    std::cout << "length: " << this->height << std ::endl;
    std::cout << "width: " << this->width << std ::endl;
    std::cout << "area: " << this->area() << std::endl;
}

Square::~Square() {}

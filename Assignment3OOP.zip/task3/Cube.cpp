#include "Cube.h"

Cube ::Cube(double side) : ThreeDimensionalShape(side, side, side) {}

Cube ::Cube(const Cube &obj) : ThreeDimensionalShape(obj) {}

Cube &Cube ::operator=(const Cube &obj)
{
    this->length = obj.length;
    this->width = obj.width;
    this->height = obj.height;
    return *this;
}

void Cube ::display(void)
{
    std::cout << "length: " << this->height << std ::endl;
    std::cout << "width: " << this->width << std ::endl;
    std::cout << "height: " << this->height << std ::endl;
    std::cout << "volume: " << this->volume() << std::endl;
}

Cube ::~Cube() {}

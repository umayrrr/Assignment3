#pragma once
#include "ThreeDimensionalShape.h"
class Cone : public ThreeDimensionalShape
{
public:
    Cone(double = 0, double = 0);
    Cone(const Cone &);
    Cone &operator=(const Cone &);
    double volume(void) const;
    void display(void);
    ~Cone();
};

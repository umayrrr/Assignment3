#include "Triangle.h"

Triangle::Triangle(double base, double height) : TwoDimensionalShape(height, base) {}

Triangle::Triangle(const Triangle &obj) : TwoDimensionalShape(obj) {}

double Triangle::area(void)
{
    return this->width * this->length * 0.5;
}

void Triangle::display(void)
{
    std::cout << "height: " << this->length << std::endl;
    std::cout << "base: " << this->width << std::endl;
    std::cout << "area: " << this->area() << std::endl;
}

Triangle::~Triangle() {}

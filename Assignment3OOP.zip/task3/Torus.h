#pragma once
#include "ThreeDimensionalShape.h"
class Torus : public ThreeDimensionalShape
{
public:
    Torus(double=0);
    Torus(const Torus &);
    Torus &operator=(const Torus &);
    double volume(void) const;
    void display(void);
    ~Torus();
};

#include "Shape.h"

Shape::Shape(double length, double width, double height)
{
	this->length = length;
	this->width = width;
	this->height = height;
}

Shape::Shape(const Shape &obj)
{
	this->length = obj.length;
	this->width = obj.width;
	this->height = obj.height;
}

Shape &Shape::operator=(const Shape &obj)
{
	this->length = obj.length;
	this->width = obj.width;
	this->height = obj.height;
	return *this;
}

double Shape::area(void) const
{
	return this->length * this->width;
}

double Shape::volume(void) const
{
	return this->length * this->height * this->width;
}

Shape::~Shape(void) {}
#pragma once
#include "TwoDimensionalShape.h"
class Circle : public TwoDimensionalShape
{
public:
	Circle(double = 0);
	Circle(const Circle &);
	Circle& operator=(const Circle &);
	double area(void) const;
	void display(void);
	~Circle();
};

#include "Hexagon.h"

Hexagon::Hexagon(double side) : TwoDimensionalShape(side, 0) {}

Hexagon::Hexagon(const Hexagon &obj) : TwoDimensionalShape(obj) {}

Hexagon &Hexagon::operator=(const Hexagon &obj)
{
    this->length = obj.length;
    this->width = obj.width;
    this->height = obj.height;
    return *this;
}

double Hexagon::area(void)
{
    return (1.44224857 / 2) * this->length * this->length;
}

void Hexagon::display(void)
{
    std::cout << "Side: " << this->length << std::endl;
    std::cout << "Area: " << this->area() << std::endl;
}

Hexagon::~Hexagon() {}

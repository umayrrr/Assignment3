#include "Player.h"

Player::Player(char *name, int matches)
{
    if (name != nullptr)
    {
        int length = 0;
        while (name[length] != '\0')
        {
            length++;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }
    this->matches = matches;
}

Player::Player(const Player &obj)
{
    if (obj.name != nullptr)
    {
        int length = 0;
        while (obj.name[length] != '\0')
        {
            length++;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = obj.name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }
    this->matches = obj.matches;
}

Player &Player::operator=(const Player &obj)
{
    if (obj.name != nullptr)
    {
        int length = 0;
        while (obj.name[length] != '\0')
        {
            length++;
        }
        if (this->name != nullptr)
        {
            delete[] name;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = obj.name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }
    this->matches = obj.matches;
    return *this;
}

char *Player::getName(void)
{
    char *temp = nullptr;
    if (this->name != nullptr)
    {
        int length = 0;
        while (this->name[length] != '\0')
        {
            length++;
        }
        temp = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            temp[i] = this->name[i];
        }
        temp[length] = '\0';
    }
    return temp;
}

int Player::getMatches(void)
{
    return this->matches;
}

void Player::display(void)
{
    std::cout << "Player Name: " << this->name << std::endl;
    std::cout << "Matches Played: " << this->matches << std::endl;
}

Player::~Player()
{
    delete[] name;
}

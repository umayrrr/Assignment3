#pragma once
#include "Player.h"
class Batsman : public Player
{
protected:
    int totScore;
    int *perMatchScore;
    double avgScore;

public:
    Batsman(char * = nullptr, int = 0, int = 0, int * = nullptr,int = 0);
    Batsman(const Batsman &);
    Batsman &operator=(const Batsman &);
    double calAvg(void);
    int getTotScore(void);
    int *getPerMatchScore(void);
    double getAvgScore(void);
    void display(void);
    ~Batsman();
};

#pragma once
#include <iostream>
class Player
{
protected:
    char *name;
    int matches;

public:
    Player(char * = nullptr, int = 0);
    Player(const Player &);
    Player &operator=(const Player &);
    char *getName(void);
    int getMatches(void);
    void display(void);
    ~Player();
};
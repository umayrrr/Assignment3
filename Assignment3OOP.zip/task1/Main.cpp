#include "Batsman.h"
#include "Bowler.h"
int main()
{
    char tempName[] = "Buhran";
    int scorePerMatch[] = {9, 8, 7};

    std::cout << "p: " << std::endl;
    Player p(tempName, 10);
    p.display();
    std::cout << "p2: " << std::endl;
    Player p2(p);
    p2.display();
    std::cout << "p3: " << std::endl;
    Player p3;
    p3 = p2;
    p3.display();

    std::cout << "b: " << std::endl;
    Batsman b(tempName, 10, 50, scorePerMatch, 3);
    b.display();
    std::cout << "b2: " << std::endl;
    Batsman b2(b);
    b2.display();
    std::cout << "b3: " << std::endl;
    Batsman b3(b);
    b3.display();

    std::cout << "bol: " << std::endl;
    Bowler bol(tempName, 10, 50);
    bol.display();
    std::cout << "bol2: " << std::endl;
    Bowler bol2(bol);
    bol2.display();
    std::cout << "bol3: " << std::endl;
    Bowler bol3(bol);
    bol3.display();
    return 0;
}

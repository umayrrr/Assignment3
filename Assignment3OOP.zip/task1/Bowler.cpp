#include "Bowler.h"

Bowler::Bowler(char *name, int matches, int noOfWickets) : Player(name, matches)
{
    this->noOfWickets = noOfWickets;
}

Bowler::Bowler(const Bowler &obj) : Player(obj)
{
    this->noOfWickets = obj.noOfWickets;
}

Bowler &Bowler::operator=(const Bowler &obj)
{
    if (obj.name != nullptr)
    {
        int length = 0;
        while (name[length] != '\0')
        {
            length++;
        }
        if (this->name != nullptr)
        {
            delete[] name;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = obj.name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }
    this->matches = obj.matches;
    this->noOfWickets = obj.noOfWickets;
    return *this;
}

void Bowler::display(void)
{
    this->Player::display();
    std::cout << "No of wickets: " << noOfWickets << std::endl;
}

Bowler::~Bowler()
{
    /*
    doNothing...........
    */
}

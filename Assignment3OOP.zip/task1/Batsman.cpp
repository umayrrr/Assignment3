#include "Batsman.h"

Batsman::Batsman(char *name, int matches, int totScore, int *perMatchScore, int size) : Player(name, matches)
{
    this->totScore = totScore;
    this->perMatchScore = new int[this->matches];
    for (int i = 0; i < this->matches; i++)
    {
        this->perMatchScore[i] = 0;
    }
    for (int i = 0; i < size; i++)
    {
        this->perMatchScore[i] = perMatchScore[i];
    }
    this->avgScore = this->calAvg();
}

Batsman::Batsman(const Batsman &obj) : Player(obj)
{
    this->totScore = obj.totScore;
    this->perMatchScore = new int[this->matches];
    for (int i = 0; i < this->matches; i++)
    {
        this->perMatchScore[i] = obj.perMatchScore[i];
    }
    this->avgScore = obj.avgScore;
}

Batsman &Batsman::operator=(const Batsman &obj)
{
    if (obj.name != nullptr)
    {
        int length = 0;
        while (name[length] != '\0')
        {
            length++;
        }
        if (this->name != nullptr)
        {
            delete[] name;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = obj.name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }
    this->matches = obj.matches;
    this->totScore = obj.totScore;
    if (this->perMatchScore != nullptr)
    {
        delete[] this->perMatchScore;
    }
    this->perMatchScore = new int[this->matches];
    for (int i = 0; i < this->matches; i++)
    {
        this->perMatchScore[i] = obj.perMatchScore[i];
    }
    this->avgScore = obj.avgScore;
    return *this;
}

double Batsman::calAvg(void)
{
    this->avgScore = 0.0;
    for (int i = 0; i < this->matches; i++)
    {
        this->avgScore += this->perMatchScore[i];
    }
    return this->avgScore /= this->matches;
}

int Batsman::getTotScore(void)
{
    return this->totScore;
}

int *Batsman::getPerMatchScore(void)
{
    int *temp;
    for (int i = 0; i < this->matches; i++)
    {
        temp[i] = perMatchScore[i];
    }

    return temp;
}

double Batsman::getAvgScore(void)
{
    return this->avgScore;
}

void Batsman::display(void)
{
    this->Player::display();
    std::cout << "Total Score: " << this->totScore << std::endl;
    std::cout << "Score Per Match: ";
    for (int i = 0; i < this->matches; i++)
    {
        std::cout << perMatchScore[i] << " ";
    }
    std::cout << std::endl;
    std::cout << "Average Score: " << this->avgScore << std::endl;
}

Batsman::~Batsman()
{
    delete[] perMatchScore;
}

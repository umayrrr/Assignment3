#pragma once
#include "Player.h"
class Bowler : public Player
{
protected:
    int noOfWickets;

public:
    Bowler(char * = nullptr, int = 0, int = 0);
    Bowler(const Bowler &);
    Bowler &operator=(const Bowler &);
    void display(void);
    ~Bowler();
};

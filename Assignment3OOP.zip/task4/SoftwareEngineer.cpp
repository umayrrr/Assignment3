#include "SoftwareEngineer.h"

SoftwareEngineer::SoftwareEngineer(char *name, char *technology)
{
    if (name != nullptr)
    {
        int length = 0;
        while (name[length] != '\0')
        {
            length++;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }

    if (technology != nullptr)
    {
        int length = 0;
        while (technology[length] != '\0')
        {
            length++;
        }
        this->technology = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->technology[i] = technology[i];
        }
        this->technology[length] = '\0';
    }
    else
    {
        this->technology = nullptr;
    }
}

SoftwareEngineer::SoftwareEngineer(const SoftwareEngineer &obj)
{
    if (obj.name != nullptr)
    {
        int length = 0;
        while (obj.name[length] != '\0')
        {
            length++;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = obj.name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }

    if (obj.technology != nullptr)
    {
        int length = 0;
        while (obj.technology[length] != '\0')
        {
            length++;
        }
        this->technology = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->technology[i] = obj.technology[i];
        }
        this->technology[length] = '\0';
    }
    else
    {
        this->technology = nullptr;
    }
}

SoftwareEngineer &SoftwareEngineer::operator=(const SoftwareEngineer &obj)
{
    if (obj.name != nullptr)
    {
        int length = 0;
        while (obj.name[length] != '\0')
        {
            length++;
        }
        if (this->name != nullptr)
        {
            delete[] this->name;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = obj.name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }

    if (obj.technology != nullptr)
    {
        int length = 0;
        while (obj.technology[length] != '\0')
        {
            length++;
        }
        if (this->technology != nullptr)
        {
            delete[] this->technology;
        }
        this->technology = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->technology[i] = obj.technology[i];
        }
        this->technology[length] = '\0';
    }
    else
    {
        this->technology = nullptr;
    }
    return *this;
}

char *SoftwareEngineer::getName(void)
{
    char *temp;
    if (this->name != nullptr)
    {
        int length = 0;
        while (this->name[length] != '\0')
        {
            length++;
        }
        temp = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            temp[i] = this->name[i];
        }
        temp[length] = '\0';
    }
    else
    {
        temp = nullptr;
    }
    return temp;
}

char *SoftwareEngineer::getTechnology(void)
{
    char *temp;
    if (this->technology != nullptr)
    {
        int length = 0;
        while (this->technology[length] != '\0')
        {
            length++;
        }
        temp = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            temp[i] = this->technology[i];
        }
        temp[length] = '\0';
    }
    else
    {
        temp = nullptr;
    }
    return temp;
}

SoftwareEngineer::~SoftwareEngineer()
{
    if (this->name != nullptr)
    {
        delete[] name;
        name = nullptr;
    }
    if (this->technology != nullptr)
    {
        delete[] technology;
        technology = nullptr;
    }
}

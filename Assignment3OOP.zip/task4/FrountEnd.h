#pragma once
#include "SoftwareEngineer.h"
class FrountEnd : virtual public SoftwareEngineer
{
public:
    FrountEnd(char * = nullptr, char * = nullptr);
    FrountEnd(const FrountEnd &);
    FrountEnd &operator=(const FrountEnd &);
    ~FrountEnd();
};

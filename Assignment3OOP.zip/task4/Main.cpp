#include "FullStackProgrammer.h"
int main()
{
    char tempName[] = "Burhan";
    char tempTechnology[] = "React.js & Node.js";
    FullStackProgrammer FSP(tempName, tempTechnology);
    FSP.display();
    return 0;
}
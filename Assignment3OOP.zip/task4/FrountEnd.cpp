#include "FrountEnd.h"

FrountEnd::FrountEnd(char *name, char *technology) : SoftwareEngineer(name, technology) {}

FrountEnd::FrountEnd(const FrountEnd &obj) : SoftwareEngineer(obj) {}

FrountEnd &FrountEnd::operator=(const FrountEnd &obj)
{
    if (obj.name != nullptr)
    {
        int length = 0;
        while (obj.name[length] != '\0')
        {
            length++;
        }
        if (this->name != nullptr)
        {
            delete[] this->name;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = obj.name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }

    if (obj.technology != nullptr)
    {
        int length = 0;
        while (obj.technology[length] != '\0')
        {
            length++;
        }
        if (this->technology != nullptr)
        {
            delete[] this->technology;
        }
        this->technology = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->technology[i] = obj.technology[i];
        }
        this->technology[length] = '\0';
    }
    else
    {
        this->technology = nullptr;
    }
    return *this;
}

FrountEnd::~FrountEnd() {}

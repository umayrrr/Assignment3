#pragma once
#include "BackEnd.h"
#include "FrountEnd.h"
class FullStackProgrammer : public BackEnd, public FrountEnd
{
public:
    FullStackProgrammer(char * = nullptr, char * = nullptr);
    FullStackProgrammer(const FullStackProgrammer &);
    FullStackProgrammer &operator=(const FullStackProgrammer &);
    void display(void);
    ~FullStackProgrammer();
};
#pragma once
#include "SoftwareEngineer.h"
class BackEnd : virtual public SoftwareEngineer
{
public:
    BackEnd(char * = nullptr, char * = nullptr);
    BackEnd(const BackEnd &);
    BackEnd &operator=(const BackEnd &);
    ~BackEnd();
};

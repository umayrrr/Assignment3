#pragma once
#include <iostream>
class SoftwareEngineer
{
protected:
    char *name;
    char *technology;

public:
    SoftwareEngineer(char * = nullptr, char * = nullptr);
    SoftwareEngineer(const SoftwareEngineer &);
    SoftwareEngineer &operator=(const SoftwareEngineer &);
    char *getName(void);
    char *getTechnology(void);
    ~SoftwareEngineer();
};

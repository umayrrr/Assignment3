#pragma once
#include "communityMember.h"
class Employee : public communityMember
{
protected:
	char *employeeCode = nullptr;

public:
	Employee(char * = nullptr, char * = nullptr);
	Employee(const Employee &);
	Employee &operator=(const Employee &);
	~Employee(void);
	char *EmployeeCodeGetter(void);
	void display(void);
};
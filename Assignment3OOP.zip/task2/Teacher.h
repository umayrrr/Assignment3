#pragma once
#include "Facility.h"
class Teacher : virtual public Facility
{
protected:
	char *course;
	char *education;

public:
	Teacher(char * = nullptr, char * = nullptr, char * = nullptr, char * = nullptr, char * = nullptr);
	~Teacher();
	Teacher(const Teacher &);
	Teacher &operator=(const Teacher &);
	void display();
	char *getCourse(void);
	char *getEducation(void);
};
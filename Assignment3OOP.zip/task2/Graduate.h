#pragma once
#include "Student.h"
class Graduate : public Student
{
public:
    Graduate(char * = nullptr, char * = nullptr);
    Graduate(const Graduate &);
    Graduate &operator=(const Graduate &);
    void display(void);
    ~Graduate();
};

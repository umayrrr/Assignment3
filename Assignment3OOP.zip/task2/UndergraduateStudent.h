#pragma once
#include "Student.h"
class UndergraduateStudent : public Student
{
protected:
    char *degreeName;

public:
    UndergraduateStudent(char * = nullptr, char * = nullptr, char * = nullptr);
    UndergraduateStudent(const UndergraduateStudent &);
    UndergraduateStudent &operator=(const UndergraduateStudent &);
    char *getDegreeName(void);
    void display(void);
    ~UndergraduateStudent();
};

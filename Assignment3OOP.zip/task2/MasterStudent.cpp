#include "MasterStudent.h"

MasterStudent::MasterStudent(char *name, char *registrationNo, char *degreeName) : Graduate(name, registrationNo)
{
    if (degreeName != nullptr)
    {
        int length = 0;
        while (degreeName[length] != '\0')
        {
            length++;
        }
        this->degreeName = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->degreeName[i] = degreeName[i];
        }
        this->degreeName[length] = '\0';
    }
    else
    {
        this->degreeName = nullptr;
    }
}

MasterStudent::MasterStudent(const MasterStudent &obj) : Graduate(obj)
{
    if (obj.degreeName != nullptr)
    {
        int length = 0;
        while (obj.degreeName[length] != '\0')
        {
            length++;
        }
        this->degreeName = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->degreeName[i] = obj.degreeName[i];
        }
        this->degreeName[length] = '\0';
    }
    else
    {
        this->degreeName = nullptr;
    }
}

MasterStudent &MasterStudent::operator=(const MasterStudent &obj)
{
    int length = 0;
    if (obj.name != nullptr)
    {
        while (obj.name[length] != '\0')
        {
            length++;
        }
        if (this->name != nullptr)
        {
            delete[] this->name;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            name[i] = obj.name[i];
        }
    }
    else
    {
        this->name = nullptr;
    }

    if (obj.registrationNo != nullptr)
    {
        int length = 0;
        while (obj.registrationNo[length] != '\0')
        {
            length++;
        }
        if (this->registrationNo != nullptr)
        {
            delete[] this->registrationNo;
        }
        this->registrationNo = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->registrationNo[i] = obj.registrationNo[i];
        }
        this->registrationNo[length] = '\0';
    }
    else
    {
        this->registrationNo = nullptr;
    }

    if (obj.degreeName != nullptr)
    {
        int length = 0;
        while (obj.degreeName[length] != '\0')
        {
            length++;
        }
        this->degreeName = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->degreeName[i] = obj.degreeName[i];
        }
        this->degreeName[length] = '\0';
    }
    else
    {
        this->degreeName = nullptr;
    }
    return *this;
}

char *MasterStudent::getDegreeName(void)
{
    char *temp = nullptr;
    if (this->degreeName != nullptr)
    {
        int length = 0;
        while (this->degreeName[length])
        {
            length++;
        }
        temp = new char[length + 1]{'\0'};
        for (int i = 0; i < length; i++)
        {
            temp[i] = this->degreeName[i];
        }
    }
    return temp;
}

void MasterStudent::display(void)
{
    this->Graduate::display();
    std::cout << "degreeName:" << this->degreeName << std::endl;
}

MasterStudent::~MasterStudent()
{
    delete[] degreeName;
}

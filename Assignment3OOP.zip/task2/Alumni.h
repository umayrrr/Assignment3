#pragma once
#include "communityMember.h"
class Alumni : public communityMember
{
protected:
    int graduationYear;

public:
    Alumni(char * = nullptr, int = 0);
    Alumni(const Alumni &);
    Alumni &operator=(const Alumni &);
    int getGraduationYear(void);
    void display(void);
    ~Alumni();
};

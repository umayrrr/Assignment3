#include "Staff.h"

Staff::Staff(char *name, char *employeeCode, char *designation) : Employee(name, employeeCode)
{
    if (designation != nullptr)
    {
        int length = 0;
        while (designation[length] != '\0')
        {
            length++;
        }
        this->designation = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->designation[i] = designation[i];
        }
        this->designation[length] = '\0';
    }
    else
    {
        this->designation = nullptr;
    }
}

Staff::Staff(const Staff &obj) : Employee(obj)
{
    if (obj.designation != nullptr)
    {
        int length = 0;
        while (obj.designation[length] != '\0')
        {
            length++;
        }
        this->designation = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->designation[i] = obj.designation[i];
        }
        this->designation[length] = '\0';
    }
    else
    {
        this->designation = nullptr;
    }
}

Staff &Staff::operator=(const Staff &obj)
{
    if (obj.name != nullptr)
    {
        int length = 0;
        while (obj.name[length] != '\0')
        {
            length++;
        }
        if (this->name != nullptr)
        {
            delete[] name;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = obj.name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }

    if (obj.employeeCode != nullptr)
    {
        int length = 0;
        while (obj.employeeCode[length] != '\0')
        {
            length++;
        }
        if (this->employeeCode != nullptr)
        {
            delete[] name;
        }
        this->employeeCode = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->employeeCode[i] = obj.employeeCode[i];
        }
        this->employeeCode[length] = '\0';
    }
    else
    {
        this->employeeCode = nullptr;
    }

    if (obj.designation != nullptr)
    {
        int length = 0;
        while (obj.designation[length] != '\0')
        {
            length++;
        }
        if (this->designation != nullptr)
        {
            delete[] name;
        }
        this->designation = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->designation[i] = obj.designation[i];
        }
        this->designation[length] = '\0';
    }
    else
    {
        this->designation = nullptr;
    }
    return *this;
}

char *Staff::getDesignation(void)
{
    char *temp = nullptr;
    if (this->designation != nullptr)
    {
        int length = 0;
        while (this->designation[length] != '\0')
        {
            length++;
        }
        temp = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            temp[i] = this->designation[i];
        }
        temp[length] = '\0';
    }
    return temp;
}

void Staff::display(void)
{
    this->Employee::display();
    std::cout << "designation: " << this->designation << std::endl;
}

Staff::~Staff()
{
    delete[] this->designation;
}

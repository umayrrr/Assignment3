#pragma once
#include "Employee.h"
class Facility : public Employee
{
protected:
    char *facility;

public:
    Facility(char * = nullptr, char * = nullptr, char * = nullptr);
    Facility(const Facility &);
    Facility &operator=(const Facility &);
    char *getFacility(void);
    void display(void);
    ~Facility();
};

#pragma once
#include "communityMember.h"
class Student : public communityMember
{
protected:
	char *registrationNo;

public:
	Student(char * = nullptr, char * = nullptr);
	~Student();
	Student(const Student &);
	Student &operator=(const Student &);
	char *getRegistrationNo(void);
	void display(void);
};
#include "AdministratorTeacher.h"
#include "Staff.h"
#include "UndergraduateStudent.h"
#include "DoctoralStudent.h"
#include "MasterStudent.h"
#include "Alumni.h"
int main()
{
    char tempName[] = "burhan";
    char tempCode[] = "l1f21bscs1059";
    char tempFacility[] = "FOIT";
    char tempDesignation[] = "PN";
    char tempCource[] = "OOP";
    char tempEducation[] = "BSCS";
    char tempAreaOfResponsibility[] = "Admission";
    char tempDegreeName[] = "CS";

    std::cout << "________________________________" << std::endl;
    std::cout << "Employee: " << std::endl;
    Employee ep(tempName, tempCode);
    ep.display();

    std::cout << "________________________________" << std::endl;
    std::cout << "Student: " << std::endl;
    Student st(tempName, tempCode);
    st.display();

    std::cout << "________________________________" << std::endl;
    std::cout << "Alumni: " << std::endl;
    Alumni al(tempName, 2019);
    al.display();

    std::cout << "________________________________" << std::endl;
    std::cout << "Facility: " << std::endl;
    Facility ft(tempName, tempCode, tempFacility);
    ft.display();

    std::cout << "________________________________" << std::endl;
    std::cout << "Staff: " << std::endl;
    Staff stf(tempName, tempCode, tempDesignation);
    stf.display();

    std::cout << "________________________________" << std::endl;
    std::cout << "Teacher: " << std::endl;
    Teacher tchr(tempName, tempCode, tempFacility, tempCource, tempEducation);
    tchr.display();

    std::cout << "________________________________" << std::endl;
    std::cout << "Administrator: " << std::endl;
    Administrator admin(tempName, tempCode, tempFacility, tempAreaOfResponsibility);
    admin.display();

    std::cout << "________________________________" << std::endl;
    std::cout << "AdministratorTeacher: " << std::endl;
    AdministratorTeacher adminTchr(tempName, tempCode, tempFacility, tempAreaOfResponsibility, tempCource, tempEducation);
    adminTchr.display();

    std::cout << "________________________________" << std::endl;
    std::cout << "UndergraduateStudent: " << std::endl;
    UndergraduateStudent ugSt(tempName, tempCode, tempDegreeName);
    ugSt.display();

    std::cout << "________________________________" << std::endl;
    std::cout << "Graduate: " << std::endl;
    Graduate gSt(tempName, tempCode);
    gSt.display();

    std::cout << "________________________________" << std::endl;
    std::cout << "DoctoralStudent: " << std::endl;
    DoctoralStudent dtSt(tempName, tempCode, tempDegreeName);
    dtSt.display();

    std::cout << "________________________________" << std::endl;
    std::cout << "MasterStudent: " << std::endl;
    MasterStudent ms(tempName, tempCode, tempDegreeName);
    ms.display();

    return 0;
}
#include "Teacher.h"

Teacher::Teacher(char *name, char *employeeCode, char *facility, char *course, char *education) : Facility(name, employeeCode, facility)
{
	if (course != nullptr)
	{
		int length = 0;
		while (course[length] != '\0')
		{
			length++;
		}
		this->course = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->course[i] = course[i];
		}
		this->course[length] = '\0';
	}
	else
	{
		this->course = nullptr;
	}

	if (education != nullptr)
	{
		int length = 0;
		while (education[length] != '\0')
		{
			length++;
		}
		this->education = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->education[i] = education[i];
		}
		this->education[length] = '\0';
	}
	else
	{
		this->education = nullptr;
	}
}

Teacher::~Teacher()
{
	delete[] course;
	delete[] education;
}

Teacher::Teacher(const Teacher &obj)
{
	if (obj.course != nullptr)
	{
		int length = 0;
		while (obj.course[length] != '\0')
		{
			length++;
		}
		this->course = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->course[i] = obj.course[i];
		}
		this->course[length] = '\0';
	}
	else
	{
		this->course = nullptr;
	}

	if (obj.education != nullptr)
	{
		int length = 0;
		while (obj.education[length] != '\0')
		{
			length++;
		}
		this->education = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->education[i] = obj.education[i];
		}
		this->education[length] = '\0';
	}
	else
	{
		this->education = nullptr;
	}
}

Teacher &Teacher::operator=(const Teacher &obj)
{
	if (obj.name != nullptr)
	{
		int length = 0;
		while (obj.name[length] != '\0')
		{
			length++;
		}
		if (this->name != nullptr)
		{
			delete[] name;
		}
		this->name = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->name[i] = obj.name[i];
		}
		this->name[length] = '\0';
	}
	else
	{
		this->name = nullptr;
	}

	if (obj.employeeCode != nullptr)
	{
		int length = 0;
		while (obj.employeeCode[length] != '\0')
		{
			length++;
		}
		if (this->employeeCode != nullptr)
		{
			delete[] name;
		}
		this->employeeCode = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->employeeCode[i] = obj.employeeCode[i];
		}
		this->employeeCode[length] = '\0';
	}
	else
	{
		this->employeeCode = nullptr;
	}

	if (obj.facility != nullptr)
	{
		int length = 0;
		while (obj.facility[length] != '\0')
		{
			length++;
		}
		if (this->facility != nullptr)
		{
			delete[] name;
		}
		this->facility = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->facility[i] = obj.facility[i];
		}
		this->facility[length] = '\0';
	}
	else
	{
		this->facility = nullptr;
	}

	if (obj.course != nullptr)
	{
		int length = 0;
		while (obj.course[length] != '\0')
		{
			length++;
		}
		if (this->course != nullptr)
		{
			delete[] this->course;
		}
		this->course = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->course[i] = obj.course[i];
		}
		this->course[length] = '\0';
	}
	else
	{
		this->course = nullptr;
	}

	if (obj.education != nullptr)
	{
		int length = 0;
		while (obj.education[length] != '\0')
		{
			length++;
		}
		if (this->education != nullptr)
		{
			delete[] this->education;
		}
		this->education = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->education[i] = obj.education[i];
		}
		this->education[length] = '\0';
	}
	else
	{
		this->education = nullptr;
	}
	return *this;
}

void Teacher::display()
{
	this->Facility::display();
	std::cout << "course: " << this->course << std::endl;
	std::cout << "Education: " << education << std::endl;
}

char *Teacher::getCourse(void)
{
	char *temp = nullptr;
	if (this->course != nullptr)
	{
		int length = 0;
		while (this->course[length])
		{
			length++;
		}
		temp = new char[length + 1]{'\0'};
		for (int i = 0; i < length; i++)
		{
			temp[i] = this->course[i];
		}
	}
	return temp;
}

char *Teacher::getEducation(void)
{
	char *temp = nullptr;
	if (this->education != nullptr)
	{
		int length = 0;
		while (this->education[length])
		{
			length++;
		}
		temp = new char[length + 1]{'\0'};
		for (int i = 0; i < length; i++)
		{
			temp[i] = this->education[i];
		}
	}
	return temp;
}

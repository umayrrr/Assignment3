#pragma once
#include "Teacher.h"
#include "Administrator.h"
class AdministratorTeacher : public Teacher, public Administrator
{
public:
    AdministratorTeacher(char * = nullptr, char * = nullptr, char * = nullptr, char * = nullptr, char * = nullptr, char * = nullptr);
    AdministratorTeacher(const AdministratorTeacher &);
    AdministratorTeacher &operator=(const AdministratorTeacher &);
    void display(void);
    ~AdministratorTeacher();
};

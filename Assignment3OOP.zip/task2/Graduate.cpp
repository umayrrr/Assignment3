#include "Graduate.h"

Graduate::Graduate(char *name, char *registrationNo) : Student(name, registrationNo) {}

Graduate::Graduate(const Graduate &obj) : Student(obj) {}

Graduate &Graduate::operator=(const Graduate &obj)
{
    int length = 0;
    if (obj.name != nullptr)
    {
        while (obj.name[length] != '\0')
        {
            length++;
        }
        if (this->name != nullptr)
        {
            delete[] this->name;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            name[i] = obj.name[i];
        }
    }
    else
    {
        this->name = nullptr;
    }

    if (obj.registrationNo != nullptr)
    {
        int length = 0;
        while (obj.registrationNo[length] != '\0')
        {
            length++;
        }
        if (this->registrationNo != nullptr)
        {
            delete[] this->registrationNo;
        }
        this->registrationNo = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->registrationNo[i] = obj.registrationNo[i];
        }
        this->registrationNo[length] = '\0';
    }
    else
    {
        this->registrationNo = nullptr;
    }
    return *this;
}

void Graduate::display(void)
{
    this->Student::display();
}

Graduate::~Graduate() {}

#pragma once
#include <iostream>
class communityMember
{
protected:
    char *name;

public:
    communityMember(char * = nullptr);
    communityMember(const communityMember &);
    communityMember &operator=(const communityMember &);
    char *getName(void);
    void display(void);
    ~communityMember();
};

#pragma once
#include "Graduate.h"
class DoctoralStudent : public Graduate
{
protected:
    char *degreeName;

public:
    DoctoralStudent(char * = nullptr, char * = nullptr, char * = nullptr);
    DoctoralStudent(const DoctoralStudent &);
    DoctoralStudent &operator=(const DoctoralStudent &);
    char *getDegreeName(void);
    void display(void);
    ~DoctoralStudent();
};

#pragma once
#include "Employee.h"
class Staff : public Employee
{
protected:
    char *designation;

public:
    Staff(char * = nullptr, char * = nullptr, char * = nullptr);
    Staff(const Staff &);
    Staff &operator=(const Staff &);
    char *getDesignation(void);
    void display(void);
    ~Staff();
};

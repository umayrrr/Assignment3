#pragma once
#include "Facility.h"
class Administrator : virtual public Facility
{
protected:
    char *areaOfRisponsibility;

public:
    Administrator(char * = nullptr, char * = nullptr, char * = nullptr, char * = nullptr);
    Administrator(const Administrator &);
    Administrator &operator=(const Administrator &);
    void display(void);
    char *getAreaOfRisponsibility(void);
    ~Administrator();
};

#include "communityMember.h"

communityMember::communityMember(char *name)
{
    if (name != nullptr)
    {
        int length = 0;
        while (name[length] != '\0')
        {
            length++;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }
}

communityMember::communityMember(const communityMember &obj)
{
    if (obj.name != nullptr)
    {
        int length = 0;
        while (obj.name[length] != '\0')
        {
            length++;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = obj.name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }
}

communityMember &communityMember::operator=(const communityMember &obj)
{
    if (obj.name != nullptr)
    {
        int length = 0;
        while (obj.name[length] != '\0')
        {
            length++;
        }
        if (this->name != nullptr)
        {
            delete[] name;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = obj.name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }
    return *this;
}

char *communityMember::getName(void)
{
    char *temp = nullptr;
    if (this->name != nullptr)
    {
        int length = 0;
        while (this->name[length] != '\0')
        {
            length++;
        }
        temp = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            temp[i] = this->name[i];
        }
        temp[length] = '\0';
    }
    return temp;
}

void communityMember::display(void)
{
    std::cout << "Name: " << this->name << std::endl;
}

communityMember::~communityMember()
{
    if (this->name != nullptr)
    {
        delete[] name;
    }
}

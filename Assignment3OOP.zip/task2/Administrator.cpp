#include "Administrator.h"

Administrator::Administrator(char *name, char *employeeCode, char *facility, char *areaOfRisponsibility) : Facility(name, employeeCode, facility)
{
    if (areaOfRisponsibility != nullptr)
    {
        int length = 0;
        while (areaOfRisponsibility[length] != '\0')
        {
            length++;
        }
        this->areaOfRisponsibility = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->areaOfRisponsibility[i] = areaOfRisponsibility[i];
        }
        this->areaOfRisponsibility[length] = '\0';
    }
    else
    {
        this->areaOfRisponsibility = nullptr;
    }
}

Administrator::Administrator(const Administrator &obj) : Facility(obj)
{
    if (obj.areaOfRisponsibility != nullptr)
    {
        int length = 0;
        while (obj.areaOfRisponsibility[length] != '\0')
        {
            length++;
        }
        this->areaOfRisponsibility = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->areaOfRisponsibility[i] = obj.areaOfRisponsibility[i];
        }
        this->areaOfRisponsibility[length] = '\0';
    }
    else
    {
        this->areaOfRisponsibility = nullptr;
    }
}

Administrator &Administrator::operator=(const Administrator &obj)
{
    if (obj.name != nullptr)
    {
        int length = 0;
        while (obj.name[length] != '\0')
        {
            length++;
        }
        if (this->name != nullptr)
        {
            delete[] name;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = obj.name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }

    if (obj.employeeCode != nullptr)
    {
        int length = 0;
        while (obj.employeeCode[length] != '\0')
        {
            length++;
        }
        if (this->employeeCode != nullptr)
        {
            delete[] name;
        }
        this->employeeCode = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->employeeCode[i] = obj.employeeCode[i];
        }
        this->employeeCode[length] = '\0';
    }
    else
    {
        this->employeeCode = nullptr;
    }

    if (obj.facility != nullptr)
    {
        int length = 0;
        while (obj.facility[length] != '\0')
        {
            length++;
        }
        if (this->facility != nullptr)
        {
            delete[] name;
        }
        this->facility = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->facility[i] = obj.facility[i];
        }
        this->facility[length] = '\0';
    }
    else
    {
        this->facility = nullptr;
    }

    if (obj.areaOfRisponsibility != nullptr)
    {
        int length = 0;
        while (obj.areaOfRisponsibility[length] != '\0')
        {
            length++;
        }
        this->areaOfRisponsibility = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->areaOfRisponsibility[i] = obj.areaOfRisponsibility[i];
        }
        this->areaOfRisponsibility[length] = '\0';
    }
    else
    {
        this->areaOfRisponsibility = nullptr;
    }
    return *this;
}

void Administrator::display(void)
{
    this->Facility::display();
    std::cout << "areaOfRisponsibility: " << this->areaOfRisponsibility << std::endl;
}

char *Administrator::getAreaOfRisponsibility(void)
{
    char *temp = nullptr;
    if (areaOfRisponsibility != nullptr)
    {
        int length = 0;
        while (this->areaOfRisponsibility[length])
        {
            length++;
        }
        temp = new char[length + 1]{'\0'};
        for (int i = 0; i < length; i++)
        {
            temp[i] = this->areaOfRisponsibility[i];
        }
    }
    return temp;
}

Administrator::~Administrator()
{
    delete[] areaOfRisponsibility;
}

#include "Employee.h"

Employee::Employee(char *name, char *employeeCode) : communityMember(name)
{
	if (employeeCode != nullptr)
	{
		int length = 0;
		while (employeeCode[length] != '\0')
		{
			length++;
		}
		this->employeeCode = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->employeeCode[i] = employeeCode[i];
		}
		this->employeeCode[length] = '\0';
	}
	else
	{
		this->employeeCode = nullptr;
	}
}

Employee::Employee(const Employee &obj) : communityMember(obj)
{
	int length = 0;
	if (obj.employeeCode != nullptr)
	{
		while (obj.employeeCode[length] != '\0')
		{
			length++;
		}
		this->employeeCode = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->employeeCode[i] = obj.employeeCode[i];
		}
	}
	else
	{
		this->employeeCode = nullptr;
	}
}

Employee &Employee::operator=(const Employee &obj)
{
	int length = 0;
	if (obj.name != nullptr)
	{
		while (obj.name[length] != '\0')
		{
			length++;
		}
		this->name = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->name[i] = obj.name[i];
		}
	}
	else
	{
		this->name = nullptr;
	}

	length = 0;
	if (obj.employeeCode != nullptr)
	{
		while (obj.employeeCode[length] != '\0')
		{
			length++;
		}
		if (obj.employeeCode != nullptr)
		{
			delete[] employeeCode;
		}
		this->employeeCode = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->employeeCode[i] = obj.employeeCode[i];
		}
	}
	else
	{
		this->employeeCode = nullptr;
	}
	return *this;
}

Employee::~Employee(void)
{
	delete[] employeeCode;
	employeeCode = nullptr;
}

char *Employee::EmployeeCodeGetter(void)
{
	char *temp = nullptr;
	if (employeeCode != nullptr)
	{
		int length = 0;
		while (employeeCode[length] != '\0')
		{
			length++;
		}
		length++;
		temp = new char[length];
		for (int i = 0; i < length; i++)
		{
			temp[i] = employeeCode[i];
		}
	}
	return temp;
}

void Employee::display(void)
{
	this->communityMember::display();
	std::cout << "employeeCode: " << this->employeeCode << std::endl;
}
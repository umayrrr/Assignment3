#include "AdministratorTeacher.h"

AdministratorTeacher::AdministratorTeacher(char *name, char *employeeCode, char *facility, char *areaOfRisponsibility, char *course, char *education) : Teacher(name, employeeCode, facility, course, education), Administrator(name, employeeCode, facility, areaOfRisponsibility), Facility(name, employeeCode, facility) {}

AdministratorTeacher::AdministratorTeacher(const AdministratorTeacher &obj) : Teacher(obj), Administrator(obj) {}

AdministratorTeacher &AdministratorTeacher::operator=(const AdministratorTeacher &obj)
{
    if (obj.name != nullptr)
    {
        int length = 0;
        while (obj.name[length] != '\0')
        {
            length++;
        }
        if (this->name != nullptr)
        {
            delete[] name;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = obj.name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }

    if (obj.employeeCode != nullptr)
    {
        int length = 0;
        while (obj.employeeCode[length] != '\0')
        {
            length++;
        }
        if (this->employeeCode != nullptr)
        {
            delete[] name;
        }
        this->employeeCode = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->employeeCode[i] = obj.employeeCode[i];
        }
        this->employeeCode[length] = '\0';
    }
    else
    {
        this->employeeCode = nullptr;
    }

    if (obj.facility != nullptr)
    {
        int length = 0;
        while (obj.facility[length] != '\0')
        {
            length++;
        }
        if (this->facility != nullptr)
        {
            delete[] name;
        }
        this->facility = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->facility[i] = obj.facility[i];
        }
        this->facility[length] = '\0';
    }
    else
    {
        this->facility = nullptr;
    }

    if (obj.areaOfRisponsibility != nullptr)
    {
        int length = 0;
        while (obj.areaOfRisponsibility[length] != '\0')
        {
            length++;
        }
        this->areaOfRisponsibility = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->areaOfRisponsibility[i] = obj.areaOfRisponsibility[i];
        }
        this->areaOfRisponsibility[length] = '\0';
    }
    else
    {
        this->areaOfRisponsibility = nullptr;
    }
    if (obj.course != nullptr)
    {
        int length = 0;
        while (obj.course[length] != '\0')
        {
            length++;
        }
        if (this->course != nullptr)
        {
            delete[] this->course;
        }
        this->course = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->course[i] = obj.course[i];
        }
        this->course[length] = '\0';
    }
    else
    {
        this->course = nullptr;
    }

    if (obj.education != nullptr)
    {
        int length = 0;
        while (obj.education[length] != '\0')
        {
            length++;
        }
        if (this->education != nullptr)
        {
            delete[] this->education;
        }
        this->education = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->education[i] = obj.education[i];
        }
        this->education[length] = '\0';
    }
    else
    {
        this->education = nullptr;
    }
    return *this;
}

void AdministratorTeacher::display(void)
{
    std::cout << "Name: " << this->name << std::endl;
    std::cout << "employeeCode: " << this->employeeCode << std::endl;
    std::cout << "facility: " << this->facility << std::endl;
    std::cout << "Area of risponsibility: " << this->areaOfRisponsibility << std::endl;
    std::cout << "course: " << this->course << std::endl;
    std::cout << "Education: " << education << std::endl;
}

AdministratorTeacher::~AdministratorTeacher() {}

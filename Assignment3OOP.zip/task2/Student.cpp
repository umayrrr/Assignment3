#include "Student.h"

Student::Student(char *name, char *registrationNo) : communityMember(name)
{
	if (registrationNo != nullptr)
	{
		int length = 0;
		while (registrationNo[length] != '\0')
		{
			length++;
		}
		this->registrationNo = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->registrationNo[i] = registrationNo[i];
		}
		this->registrationNo[length] = '\0';
	}
	else
	{
		this->registrationNo = nullptr;
	}
}

Student::~Student()
{
	delete[] this->registrationNo;
}

Student::Student(const Student &obj) : communityMember(name)
{
	if (obj.registrationNo != nullptr)
	{
		int length = 0;
		while (obj.registrationNo[length] != '\0')
		{
			length++;
		}
		this->registrationNo = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->registrationNo[i] = obj.registrationNo[i];
		}
		this->registrationNo[length] = '\0';
	}
	else
	{
		this->registrationNo = nullptr;
	}
}

Student &Student::operator=(const Student &obj)
{
	int length = 0;
	if (obj.name != nullptr)
	{
		while (obj.name[length] != '\0')
		{
			length++;
		}
		if (this->name != nullptr)
		{
			delete[] this->name;
		}
		this->name = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			name[i] = obj.name[i];
		}
	}
	else
	{
		this->name = nullptr;
	}

	if (obj.registrationNo != nullptr)
	{
		int length = 0;
		while (obj.registrationNo[length] != '\0')
		{
			length++;
		}
		if (this->registrationNo != nullptr)
		{
			delete[] this->registrationNo;
		}
		this->registrationNo = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			this->registrationNo[i] = obj.registrationNo[i];
		}
		this->registrationNo[length] = '\0';
	}
	else
	{
		this->registrationNo = nullptr;
	}
	return *this;
}

char *Student::getRegistrationNo(void)
{
	char *temp = nullptr;
	if (this->registrationNo != nullptr)
	{
		int length = 0;
		while (this->registrationNo[length])
		{
			length++;
		}
		temp = new char[length + 1]{'\0'};
		for (int i = 0; i < length; i++)
		{
			temp[i] = this->registrationNo[i];
		}
	}
	return temp;
}

void Student::display(void)
{
	this->communityMember::display();
	std::cout << "registration no: " << registrationNo << std::endl;
}
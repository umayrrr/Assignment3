#pragma once
#include"Graduate.h"
class MasterStudent:public Graduate
{
protected:
    char *degreeName;

public:
    MasterStudent(char * = nullptr, char * = nullptr, char * = nullptr);
    MasterStudent(const MasterStudent &);
    MasterStudent &operator=(const MasterStudent &);
    char *getDegreeName(void);
    void display(void);
    ~MasterStudent();
};

#include "Facility.h"

Facility::Facility(char *name, char *employeeCode, char *facility) : Employee(name, employeeCode)
{
    if (facility != nullptr)
    {
        int length = 0;
        while (facility[length] != '\0')
        {
            length++;
        }
        this->facility = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->facility[i] = facility[i];
        }
        this->facility[length] = '\0';
    }
    else
    {
        this->facility = nullptr;
    }
}

Facility::Facility(const Facility &obj) : Employee(obj)
{
    if (obj.facility != nullptr)
    {
        int length = 0;
        while (obj.facility[length] != '\0')
        {
            length++;
        }
        this->facility = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->facility[i] = obj.facility[i];
        }
        this->facility[length] = '\0';
    }
    else
    {
        this->facility = nullptr;
    }
}

Facility &Facility::operator=(const Facility &obj)
{
    if (obj.name != nullptr)
    {
        int length = 0;
        while (obj.name[length] != '\0')
        {
            length++;
        }
        if (this->name != nullptr)
        {
            delete[] name;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = obj.name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }

    if (obj.employeeCode != nullptr)
    {
        int length = 0;
        while (obj.employeeCode[length] != '\0')
        {
            length++;
        }
        if (this->employeeCode != nullptr)
        {
            delete[] name;
        }
        this->employeeCode = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->employeeCode[i] = obj.employeeCode[i];
        }
        this->employeeCode[length] = '\0';
    }
    else
    {
        this->employeeCode = nullptr;
    }

    if (obj.facility != nullptr)
    {
        int length = 0;
        while (obj.facility[length] != '\0')
        {
            length++;
        }
        if (this->facility != nullptr)
        {
            delete[] name;
        }
        this->facility = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->facility[i] = obj.facility[i];
        }
        this->facility[length] = '\0';
    }
    else
    {
        this->facility = nullptr;
    }
    return *this;
}

char *Facility::getFacility(void)
{
    char *temp = nullptr;
    if (this->facility != nullptr)
    {
        int length = 0;
        while (this->facility[length] != '\0')
        {
            length++;
        }
        temp = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            temp[i] = this->facility[i];
        }
        temp[length] = '\0';
    }
    return temp;
}

void Facility::display(void)
{
    this->Employee::display();
    std::cout << "facility: " << this->facility << std::endl;
}

Facility::~Facility()
{
    delete[] this->facility;
}

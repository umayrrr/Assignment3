#include "Alumni.h"

Alumni::Alumni(char *name, int graduationYear) : communityMember(name)
{
    this->graduationYear = graduationYear;
}

Alumni::Alumni(const Alumni &obj) : communityMember(obj)
{
    this->graduationYear = obj.graduationYear;
}

Alumni &Alumni::operator=(const Alumni &obj)
{
    if (obj.name != nullptr)
    {
        int length = 0;
        while (obj.name[length] != '\0')
        {
            length++;
        }
        if (this->name != nullptr)
        {
            delete[] name;
        }
        this->name = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            this->name[i] = obj.name[i];
        }
        this->name[length] = '\0';
    }
    else
    {
        this->name = nullptr;
    }
    this->graduationYear = obj.graduationYear;
    return *this;
}

int Alumni::getGraduationYear(void)
{
    return this->graduationYear;
}

void Alumni::display(void)
{
    this->communityMember::display();
    std::cout << "Graduation Year: " << this->graduationYear << std::endl;
}

Alumni::~Alumni() {}
